var express=require("express");
var bodyParser=require('body-parser');
var app = express();
var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
var session = require('express-session');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(session({resave: true, saveUninitialized: true, secret: 'XCR3rsasa%RDHHH', cookie: { maxAge: 60000 }}));


//app.use('/register',registerController);
//app.use('/authenticate',authenticateController);
/* route to handtration */
app.post('/api/register',registerController.register);
app.post('/api/authenticate',authenticateController.authenticate);

app.get('/logout',function(req,res){
    sessionData = req.session;
    //res.json({sessionData});
    sessionData.destroy(function(err) {
        if(err){
            msg = 'Error destroying session';
            res.json(msg);
        }else{
            msg = 'Session destroy successfully';
            console.log(msg)
            res.json(msg);
        }
    });
});

//module.exports=app;
app.listen(8080)