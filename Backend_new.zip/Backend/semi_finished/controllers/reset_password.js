var connection = require('./../config');
var express=require('express');
var router=express.Router();
var session=require('express-session');
module.exports.resetpass=function(req,res){
	//user_id from session
	var sess=req.session;
	var user =  req.session.user,
    user_id = req.session.user_id;
	//user_id=1;
	
	connection.query("update login set password=? where user_id=?",[req.body.new_pass,user_id],function(errormain,resultmain,fieldmain){
		if(errormain){res.json({message:"Some error occured!!"});}
		else{
			res.json({
			status:true,
			message: "Password Reset"});
		}
	});
}