var connection = require('./../config');
var express=require('express');
var router=express.Router();
//doctor_id will come from session value
module.exports.unavailable=function(req,res){
	var doctor_id=2;
	
	connection.query("insert into unavailable (doctor_id,date,details) values (?,?,?)",[doctor_id,req.body.date,req.body.details],function(errormain,resultmain,fieldmain){
		if(errormain){res.json({message:errormain});}
		else{
			res.json({
			status:true,
			message: 'Value Saved !!'});
		}
	});
}