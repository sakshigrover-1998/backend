var connection = require('./../config');
var express=require('express');
var router=express.Router();

module.exports.time_available=function(req,res){
	var sess=req.session;
    var user =  req.session.user,
    doctor_id = req.session.doctor_id;
	connection.query("select time from appintments where doctor_id=? and date=?",[doctor_id,req.body.date],function(errormain,resultmain,fieldmain){
		if(errormain){res.json({message:errormain});}
		else{
			res.json({
			status:true,
			message:resultmain});
		}
	});
}