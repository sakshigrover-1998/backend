var connection = require('./../config');
var express=require('express');
var router=express.Router();
var session=require('express-session');

module.exports.date_available=function(req,res){
	var sess=req.session;
    var user =  req.session.user,
    doctor_id = req.session.doctor_id;
	connection.query("select date from unavailable where doctor_id=?",[req.body.doctor_id],function(errormain,resultmain,fieldmain){
		if(errormain){res.json({message:errormain});}
		else{
			res.json({
			status:true,
			message:resultmain});
		}
	});
}