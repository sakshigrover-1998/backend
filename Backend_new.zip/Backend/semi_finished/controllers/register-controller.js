var connection = require('./../config');
var express=require('express');
var router=express.Router();
const bcrypt = require('bcrypt');
const saltRounds = 10;
var session = require('express-session');
var app=express();
var passport=require('passport');
var bodyParser=require('body-parser');
var createError = require("http-errors");

var path = require("path");
var cookieParser = require("cookie-parser");


/*router.get('/',function(req,res){
	console.log(req.session.user);
	console.log(req.authenticate())
	res.render('profile',{title:'profile'});
});*/

/*router.get('/profile',authenticate(), function(req,res){
	console.log(req.session.user);
	console.log(req.authenticate())
	res.render('home',{title:'Home'});
});*/

/*app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// set up the session
app.use(
  session({
    secret: "app",
    name: "app",
    resave: true,
    saveUninitialized: true
    // cookie: { maxAge: 6000 } /* 6000 ms? 6 seconds -> wut? :S 
  })
);*/

function save_doctor(user_id,specialization,experience,qualification,department_id){
				  connection.query('Insert into doctor (user_id_ref,specialization,qualification,department_id,experience) values (?,?,?,?,?)',[user_id,specialization,qualification,department_id,experience],function(errord,resultsd,fieldsd)
				 {if (errord) {
        console.log(errord);
			  return false;}
			  else{ return true;}
			  });
			 
}

module.exports.register=function(req,res){
	var email=req.body.email;
	var phone=req.body.phone;
	var type=req.body.type;
	var username=req.body.username;
	var user_id;
	var specialization=req.body.specialization;
	var qualification=req.body.qualification;
	var experience=req.body.experience;
	var department_id=req.body.department_id;

	
	connection.query("select user_id from login where email=? and phone=?",[email,phone],function(errormain,resultmain,fieldmain){
		if(errormain){res.json({message:errormain});}
		if(resultmain.length == 0){
			bcrypt.hash(password, saltRounds, function(err, hash) {
				// Store hash in your password DB.
				connection.query('INSERT into login (firstname,lastname,phone,password,email,user_type,age,gender,address) values (?,?,?,?,?,?,?,?,?)',[req.body.firstname,req.body.lastname,phone,req.body.password,email,type,req.body.age,req.body.gender,req.body.address] ,function (error, results, fields) {
					if (error) {
					  res.json({
						 status:false,
						  message:error,
						  
					  });
					}
					else{
						connection.query('Select user_id from login where email=? and phone=?',[email,phone],function(errorm,resultsm,fieldsm){if (error) {
					  res.json({
						 status:false,
						  message:error,
						  
					  });
					}
					else{user_id=resultsm[0].user_id;
							//console.log(user_id);
							//console.log(type);
						if (type==1){
							var r=save_doctor(user_id,specialization,experience,qualification,department_id);
							console.log(r);
						}
							//console.log("HIIi"); 
						}
						});
						connection.query('SELECT LAST_INSERT_ID() as user_id', function(error, results, fields){
							if(error) throw error;
                            const user_id = results[0];
							console.log(results[0]);

							req.login(user_id, function(err){
								res.redirect('/');
							
							 res.json({
								status:true,
								message:'User registered sucessfully'
							    });
							});
						});
						
				    }
				});
			});
			
    
		}
		
		else{
			res.json({
			status:false,
			message:"Email or phone number aldready exists."});
		}
		
	});
}
/*passport.serializeUser(function(user, done) {
	done(null, user_id);
  });
  
  passport.deserializeUser(function(user_id, done) {
	User.findById(id, function (err, user) {
	  done(err, user);
	});
});	

function authenticate () {
	return(req, res, next) => {
		console.log(`
			req.session.passport.user: $(JSON.
				stringify(req.session.passport)}`);
		if(req.authenticate()) return next(
		    );
		  res.redirect('/register')
		
		
	}
}*/