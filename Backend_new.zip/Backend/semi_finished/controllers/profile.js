var connection = require('./../config');
var express=require('express');
var router=express.Router();
const session = require("express-session");
//user_id will come from session value

module.exports.profile= function(req,res){
	var sess=req.session;
	var user =  req.session.user,
	user_id = req.session.user_id;
	var ans;
		connection.query("select user_type,email,phone,age,gender,username from login where user_id=?",[user_id],function(errormain,resultmain,fieldmain){
			if(errormain){res.json({message:errormain})}
			else{
				ans=resultmain;
				if(resultmain[0].user_type==1){
					//ans=Object.assign({a:1},{b:2},ans)
					connection.query("select experience,qualification,specialization,department_name from doctor inner join department on doctor.department_id=department.department_id where user_id_ref=?",[user_id],function(error,result,field){
							if(error){
								res.json({message:error})
							}
							else{
								ans=ans.concat(result)
								//ans={...result,...resultmain};
								//ans=Object.assign(result,resultmain);
								//res.json({message:ans});
							}
				
					});}
				res.json({
					status:true,
					message:ans})
			}
		})
}