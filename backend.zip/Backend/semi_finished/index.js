var mysql=require('mysql');

var express=require("express");
var bodyParser=require('body-parser');


const bcrypt=require('bcrypt');
const saltRounds=10;
var session=require('express-session');
var passport=require('passport');
var MySQLStore = require('express-mysql-session')(session);
var app = express();
var options = {
    // Host name for database connection:
    host: '35.200.193.123',
    // Port number for database connection:
    port: 3306,
    // Database user:
    user: 'sakshi',
    // Password for the above database user:
    password: 'summer2020',
    // Database name:
    database: 'test_db',
    // Whether or not to automatically check for and clear expired sessions:
    clearExpired: true,
    // How frequently expired sessions will be cleared; milliseconds:
    checkExpirationInterval: 900000,
    // The maximum age of a valid session; milliseconds:
    expiration: 86400000,
    // Whether or not to create the sessions database table, if one does not already exist:
    createDatabaseTable: true,
    // Number of connections when creating a connection pool:
    connectionLimit: 1,
    // Whether or not to end the database connection when the store is closed.
    // The default value of this option depends on whether or not a connection was passed to the constructor.
    // If a connection object is passed to the constructor, the default value for this option is false.
    endConnectionOnClose: true,
    charset: 'utf8mb4_bin',
    schema: {
        tableName: 'sessions',
        columnNames: {
            session_id: 'session_id',
            expires: 'expires',
            data: 'data'
        }
    }
};

var connection = mysql.createConnection(options); // or mysql.createPool(options);
var sessionStore = new MySQLStore({}/* session store options */, connection);

var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
var appointmentsRouter = require('./controllers/appointments');
var medicalrecordsRouter=require('./controllers/view_medical_record');
var save_medicalrecordsRouter=require('./controllers/save_medicalrecords');
var profileRouter=require('./controllers/profile');
var editprofileRouter=require('./controllers/edit_profile');
var save_editprofileRouter=require('./controllers/profile_save');
var reg_departmentRouter=require('./controllers/departments');
var forgotpassRouter = require('./controllers/forgot_password');
var resetpassRouter = require('./controllers/reset_password');
var unavailableRouter = require('./controllers/unavailable');
var save_deptRouter = require('./controllers/save_departments');
var particular_recordRouter = require('./controllers/particular_record');
var view_doctorRouter = require('./controllers/view_doctor');
var time_availableRouter = require('./controllers/time_available');
var date_availableRouter = require('./controllers/date_available');

app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
//app.use(session({resave: true, saveUninitialized: true, secret: 'XCR3rsasa%RDHHH', cookie: { maxAge: 60000 }}));


app.use(session({
    secret: 'keyboard cat',
    resave: false,
    store: sessionStore,
    saveUninitialized: true,
   // cookie: { secure: true }
  }))
app.use(passport.initialize());
app.use(passport.session());

app.post('/register',registerController.register);
app.post('/authenticate',authenticateController.authenticate);
app.post('/appointments',appointmentsRouter.appointments);
app.post('/reset_password',resetpassRouter.resetpass);
app.post('/forgot_password',forgotpassRouter.forgotpass);
app.get('/medical_records',medicalrecordsRouter.records);
app.post('/save_medical_records',save_medicalrecordsRouter.save_records);
app.get('/medical_records/particular',particular_recordRouter.particular_record);
app.get('/profile',profileRouter.profile);
//app.get('/profile/edit',editprofileRouter.editprofile);
app.post('/profile/save_edit',save_editprofileRouter.save_editprofile);
app.get('/register/department',reg_departmentRouter.departments);
app.get('/department/doctor',view_doctorRouter.view_doctor);
app.post('/unavailable',unavailableRouter.unavailable);
app.post('/save_department',save_deptRouter.save_dept);
app.get('/appointments/time_available',time_availableRouter.time_available);
app.get('/appointments/date_available',date_availableRouter.date_available);
//session destroy
app.get('/logout',function(req,res){
    sessionData = req.session;
    sessionData.destroy(function(err) {
        if(err){
            msg = 'Error destroying session';
            res.json(msg);
        }else{
            msg = 'Session destroy successfully';
            console.log(msg)
            res.json(msg);
        }
    });
});


//module.exports=app;
app.listen(8080) 