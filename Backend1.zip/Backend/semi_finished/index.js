var mysql=require('mysql');
const uuid = require('uuid/v4')
var express=require("express");
var bodyParser=require('body-parser');
var createError = require("http-errors");

var path = require("path");
var cookieParser = require("cookie-parser");

var debug = require("debug")("index.js");


const bcrypt=require('bcrypt');
const saltRounds=10;
var session=require('express-session');
var passport=require('passport');



/*var options = {
    // Host name for database connection:
    host: '35.200.193.123',
    // Port number for database connection:
    port: 3306,
    // Database user:
    user: 'sakshi',
    // Password for the above database user:
    password: 'summer2020',
    // Database name:
    database: 'test_db',
    // Whether or not to automatically check for and clear expired sessions:
    clearExpired: true,
    // How frequently expired sessions will be cleared; milliseconds:
    checkExpirationInterval: 900000,
    // The maximum age of a valid session; milliseconds:
    expiration: 86400000,
    // Whether or not to create the sessions database table, if one does not already exist:
    createDatabaseTable: true,
    // Number of connections when creating a connection pool:
    connectionLimit: 1,
    // Whether or not to end the database connection when the store is closed.
    // The default value of this option depends on whether or not a connection was passed to the constructor.
    // If a connection object is passed to the constructor, the default value for this option is false.
    endConnectionOnClose: true,
    charset: 'utf8mb4_bin',
    schema: {
        tableName: 'sessions',
        columnNames: {
            session_id: 'session_id',
            expires: 'expires',
            data: 'data'
        }
    }
};

var connection = mysql.createConnection(options); // or mysql.createPool(options);
var sessionStore = new MySQLStore({}, connection); */



var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
var appointmentsRouter = require('./controllers/appointments');
var medicalrecordsRouter=require('./controllers/view_medical_record');
var save_medicalrecordsRouter=require('./controllers/save_medicalrecords');
var profileRouter=require('./controllers/profile');
var editprofileRouter=require('./controllers/edit_profile');
var save_editprofileRouter=require('./controllers/profile_save');
var reg_departmentRouter=require('./controllers/departments');
var forgotpassRouter = require('./controllers/forgot_password');
var resetpassRouter = require('./controllers/reset_password');
var unavailableRouter = require('./controllers/unavailable');
var save_deptRouter = require('./controllers/save_departments');
var particular_recordRouter = require('./controllers/particular_record');
var view_doctorRouter = require('./controllers/view_doctor');
var time_availableRouter = require('./controllers/time_available');
var date_availableRouter = require('./controllers/date_available');

var app = express();
//app.use(session({resave: true, saveUninitialized: true, secret: 'XCR3rsasa%RDHHH', cookie: { maxAge: 60000 }}));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// set up the session
app.use(
  session({
    secret: "app",
    name: "app",
    resave: true,
    saveUninitialized: true
    // cookie: { maxAge: 6000 } /* 6000 ms? 6 seconds -> wut? :S */
  })
);

var logout = function(req, res, next) {
    debug("logout()");
    req.session.loggedIn = false;
    res.redirect("/");
};

var login = function(req, res, next) {
    var { username, password } = req.body;
    if (req.body.username && checkUser(username, password)) {
      debug("login()", username, password);
      req.session.loggedIn = true;
      res.redirect("/");
    } else {
      debug("login()", "Wrong credentials");
      res.render("login", { title: "Login Here", error: "Wrong credentials" });
    }
};

var checkLoggedIn = function(req, res, next) {
    if (req.session.loggedIn) {
      debug(
        "checkLoggedIn(), req.session.loggedIn:",
        req.session.loggedIn,
        "executing next()"
      );
      next();
    } else {
      debug(
        "checkLoggedIn(), req.session.loggedIn:",
        req.session.loggedIn,
        "rendering login"
      );
      res.render("login", { title: "Login Here" });
    }
};




/*app.use(session({
    genid: (req) => {
      console.log('Inside the session middleware')
      console.log(req.sessionID)
      return uuid() // use UUIDs for session IDs
    },
    store: sessionStore,
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized:false
  }))
app.use(passport.initialize());
app.use(passport.session());
passport.use(sessions.createStrategy());*/

/*passport.serializeUser(sessions.serializeUser());
passport.deserializeUser(sessions.deserializeUser());*/

app.post('/register',registerController.register);
app.post('/authenticate',authenticateController.authenticate);
app.post('/appointments',function(req,res,next){
    appointmentsController.appointments;
});
app.post('/reset_password',resetpassRouter.resetpass);
app.post('/forgot_password',forgotpassRouter.forgotpass);
app.get('/medical_records',medicalrecordsRouter.records);
app.post('/save_medical_records',save_medicalrecordsRouter.save_records);
app.get('/medical_records/particular',particular_recordRouter.particular_record);
app.get('/profile',profileRouter.profile);
//app.get('/profile/edit',editprofileRouter.editprofile);
app.post('/profile/save_edit',save_editprofileRouter.save_editprofile);
app.get('/register/department',reg_departmentRouter.departments);
app.get('/department/doctor',view_doctorRouter.view_doctor);
app.post('/unavailable',unavailableRouter.unavailable);
app.post('/save_department',save_deptRouter.save_dept);
app.get('/appointments/time_available',time_availableRouter.time_available);
app.get('/appointments/date_available',date_availableRouter.date_available);
//session destroy



/*app.get('/logout',function(req,res){
    delete req.session;
    req.session.save(function(){
        res.redirect('/');
    })
});*/


module.exports=app;
app.listen(8080) 